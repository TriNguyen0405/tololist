const List = class {
	constructor() {
		this.$form = $('#itemForm');
		this.$input = $('#item');
		this.$container = $('#todo-list');
		this.items = [];
		this.init();
	}
	init() {
		fetch('/getitems')
		.then(response => response.json())
		.then(data => {
			this.items = data.items;
			this.show();
		})
		.catch(err => console.log(err));

		$('#itemForm').on('submit', (e)=>{ this.add(e)} )
	}

	show() {
		this.items.forEach(item => {
			$('#todolist').append(`<li class="items"><span class="item">${item}</span></li>`);
		});
	}

	add(e) {
		e.preventDefault();
		const newItem = $('#item').val();
		this.append(newItem);
		this.save(newItem);
		$('#item').val('');
	}

	append(item) {
		console.log(this.items, item);
		this.items.push(item);
		$('#todolist').append(`<li class="items"><span class="item">${item}</span></li>`);
	}

	save(item) {
		fetch('/setitem', {
			method: 'post',
			body: JSON.stringify({"newitem": item}),
			headers: {
				'Content-Type': 'application/json'
			}
		})
		.then(response => response.json())
		.then(data => {})
		.catch(err => console.log(err));
	}
};
new List();

// ==============================

function searchTask() {
    var input, filter, ul, li, title, i, txtValue;
    input = document.getElementById("searchTask");
    filter = input.value.toLowerCase();
    ul = document.getElementById("todolist");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        title = li[i].getElementsByClassName("item")[0];
        txtValue = title.textContent || title.innerText;
        if (txtValue.toLowerCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}