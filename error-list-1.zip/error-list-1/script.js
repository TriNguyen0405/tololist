let arrayData = [];

$(document).ready(function(){
    loadData();
    searchTask();
    // unLoadForm();
});

function unLoadForm() {
    $('.form-task').submit(function(e){
        e.preventDefault();
    });
}

function loadData(){
    $.ajax( './data.json', {
        dataType: 'json',
    })
    .done(function( data ) {
        arrayData = data;
        
        $('.form-action button[type="submit"]').click(function(){
            var valTitle = $('#titleName').val();
            // var valDescription = $('#description').val();
    
            if(valTitle === '') {
                $('#titleName').attr('placeholder','Value not empty').addClass('error');
                return false;
            }else {

                if(localStorage.getItem('product')===null){
                    arrayData.push({"title":valTitle});
                    $('#titleName').val("").focus();
                    localStorage.setItem('product', JSON.stringify(arrayData));
                }else {
                    var newJson = localStorage.getItem('product').replace(/([a-zA-Z0-9]+?):/g, '"$1":');
                    newJson = newJson.replace(/'/g,);
                    var data = JSON.parse(newJson);
                    
                    data.push({"title":valTitle});

                    // reset field then submit.
                    $('#titleName').val("").focus();
                    // $('#description').val("").focus();
                    localStorage.setItem('product', JSON.stringify(data));
                }
            }
        });

        if(localStorage.getItem('product')===null){
            arrayData.map(element => {
                $("#todolist").append(
                    `<li class="item">
                        <div class="title-error">${element.title}</div>
                    </li>`
                )
            }) 
        }
        else{
            arrayData = localStorage.getItem('product');

            var newJson = localStorage.getItem('product').replace(/([a-zA-Z0-9]+?):/g, '"$1":');
            newJson = newJson.replace(/'/g);
            var data = JSON.parse(newJson);

            data.map(element => {
                $("#todolist").append(
                    `<li class="item">
                        <div class="title-error">${element.title}</div>
                    </li>`
                )
                $('.cancel-btn').click(function(){
                    $(this).parent('li').fadeOut();
                })
            })
        } 
    });
}

function searchTask() {
    var input, filter, ul, li, title, i, txtValue;
    input = document.getElementById("searchTask");
    filter = input.value.toLowerCase();
    ul = document.getElementById("todolist");
    li = ul.getElementsByTagName("li");
    for (i = 0; i < li.length; i++) {
        title = li[i].getElementsByClassName("title-error")[0];
        txtValue = title.textContent || title.innerText;
        if (txtValue.toLowerCase().indexOf(filter) > -1) {
            li[i].style.display = "";
        } else {
            li[i].style.display = "none";
        }
    }
}